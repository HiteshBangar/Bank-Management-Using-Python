# Bank-Management-System

This project basically displays the account details of a person like his/her name, Account no. , Account Balance, and also on certain deposits like Fixed Deposit and Recurring Deposit.

The main feature includes: 
 - Object Oriented concepts
 - Exception Handling

## To Run
```
$ python Bank.py
```
